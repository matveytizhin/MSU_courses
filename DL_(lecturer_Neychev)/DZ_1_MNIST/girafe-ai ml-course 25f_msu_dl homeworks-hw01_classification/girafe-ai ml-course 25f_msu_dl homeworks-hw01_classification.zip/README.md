* Derivatives implementation Classification: [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/girafe-ai/ml-course/blob/25f_msu_dl/homeworks/hw01_classification/01_derivatives.ipynb)


* MNIST Classification: [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/girafe-ai/ml-course/blob/25f_msu_dl/homeworks/hw01_classification/02_hw_mnist_classification.ipynb)